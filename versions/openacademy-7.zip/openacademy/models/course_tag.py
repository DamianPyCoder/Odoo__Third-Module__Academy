# -*- coding: utf-8 -*-

from odoo import models, fields, api


class CourseTag(models.Model):

    _name = 'openacademy.course_tag'
    _sql_constraints = [('check_name_unique', 'UNIQUE(name)' ,'A course tag name must be unique')]

    name = fields.Char(required=True)
