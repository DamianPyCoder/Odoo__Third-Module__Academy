# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError

class Session(models.Model):
    _name = 'openacademy.session'

    name = fields.Char(string="Title", required=True)
    start_date = fields.Date(string="Start date")
    classroom_id = fields.Many2one('openacademy.classroom')

    instructor_id = fields.Many2one('res.partner', domain=[('is_instructor', '=', True)])
    course_id = fields.Many2one('openacademy.course')
    attendee_ids = fields.Many2many('res.partner')

    number_of_seats = fields.Integer(compute="_compute_number_of_seats")
    taken_seats = fields.Integer(compute='_compute_taken_seats')

    state = fields.Selection([('new','New'),
                              ('planned', 'Planned'),
                              ('done','Done'),
                              ('cancelled','Cancelled')], default='new')


    @api.depends('classroom_id')
    def _compute_number_of_seats(self):
        for record in self:
            if record.classroom_id:
                record.number_of_seats = record.classroom_id.number_of_seats
            else:
                record.number_of_seats = 0

    @api.depends('number_of_seats','attendee_ids')
    def _compute_taken_seats(self):
        for record in self:
            if record.number_of_seats and record.number_of_seats > 0:
                record.taken_seats = len(record.attendee_ids)*100/record.number_of_seats
            else:
                record.taken_seats = 0

    @api.onchange('start_date')
    def _onchange_start_date(self):
        if self.start_date and self.state == 'new':
            self.state = 'planned'

    def session_done(self):
        for record in self:
            if record.state != 'planned':
                raise UserError("Only planned session can be done")
            else:
                record.state = 'done'
        return True

    def session_cancel(self):
        for record in self:
            if record.state == 'done':
                raise UserError("Done sessions can not be cancelled")
            else:
                record.state = 'cancelled'
        return True

    @api.constrains('attendee_ids','number_of_seats')
    def check_participants_with_seats(self):
        for record in self:
            if record.number_of_seats < len(record.attendee_ids):
                raise ValidationError('The classroom has only place for '+ str(record.number_of_seats) +' students')
    
    def unlink(self):
        for record in self:
            if record.state == 'planned':
                raise UserError('Sessions with state planned can not be removed')
        return super().unlink()