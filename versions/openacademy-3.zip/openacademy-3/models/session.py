# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Session(models.Model):
    _name = 'openacademy.session'

    name = fields.Char(string="Title", required=True)
    start_date = fields.Date(string="Start date")
    duration = fields.Integer()
    number_of_seats = fields.Integer(string="Number of seats")

    instructor_id = fields.Many2one('res.partner')
    course_id = fields.Many2one('openacademy.course')
    attendee_ids = fields.Many2many('res.partner')

